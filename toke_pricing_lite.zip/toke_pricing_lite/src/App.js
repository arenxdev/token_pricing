import React, { useState } from 'react';
import { Container, Typography, TextField, Button, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material';

function App() {
  // Estado para almacenar las tarifas pendientes de aprobación
  const [pendingTarifas, setPendingTarifas] = useState([]);

  // Estado para almacenar las tarifas aprobadas
  const [approvedTarifas, setApprovedTarifas] = useState([]);

  // Estado para los campos del formulario
  const [nombre, setNombre] = useState('');
  const [fechaEfectiva, setFechaEfectiva] = useState('');
  const [costoUnitario, setCostoUnitario] = useState('');

  // Estado para los campos del formulario
  const [fechaActual, setFechaActual] = useState(new Date());

  //Util
  function isSameDay(date1, date2) {
    return (
      date1.getFullYear() === date2.getFullYear() &&
      date1.getMonth() === date2.getMonth() &&
      date1.getDate() === date2.getDate()
    );
  }

  //Manejar Submit schedule
  const handleSubmitSchedule = (e) => {
    e.preventDefault();
    var candidates = approvedTarifas.filter(tarifa => isSameDay(tarifa.fechaEfectivaDate, fechaActual));
    if (candidates.length === 0)
      return;
    
    candidates.sort((a, b) => b.fechaCreacion - a.fechaCreacion);
    candidates[0] = {...candidates[0], estado: 'ACTIVE'}
    for (let i = 1; i < candidates.length; i++) {
      candidates[i] = {...candidates[0], estado: 'EXPIRED'}
    }
  };

  // Manejar el envío del formulario para agregar una nueva tarifa pendiente de aprobación
  const handleSubmit = (e) => {
    e.preventDefault();
    const newTarifa = {
      nombre,
      fechaEfectiva,
      fechaEfectivaDate: new Date(fechaEfectiva),
      costoUnitario,
      estado: 'PENDING_APPROVAL',
      fechaCreacion: new Date(),
    };
    setPendingTarifas([...pendingTarifas, newTarifa]);
    // Limpiar campos del formulario
    setNombre('');
    setFechaEfectiva('');
    setCostoUnitario('');
  };

  // Función para aprobar una tarifa pendiente
  const handleApprove = (index) => {
    const approvedTarifa = pendingTarifas[index];
    const list = determineTarifas(approvedTarifa)
    list.sort((a, b) => b.fechaEfectivaDate.getTime() !== a.fechaEfectivaDate.getTime() ?  b.fechaEfectivaDate - a.fechaEfectivaDate : b.fechaCreacion - a.fechaCreacion);
    setApprovedTarifas(list);
    // Eliminar la tarifa aprobada de la lista de pendientes
    setPendingTarifas(pendingTarifas.filter((_, i) => i !== index));
  };

  // Función para determinar el estado de una tarifa aprobada
  const determineTarifas = (approvedTarifa) => {
    const currentDate = new Date();
    const tarifaDate = approvedTarifa.fechaEfectivaDate;

    if (tarifaDate > currentDate)
      return [...approvedTarifas, {...approvedTarifa, estado: "PENDING" }];

    const activeIndex = approvedTarifas.findIndex(tarifa => tarifa.estado === "ACTIVE");
    const activeTarifa = approvedTarifas[activeIndex];
  
    if (activeIndex === -1)
      return [...approvedTarifas, { ...approvedTarifa, estado: "ACTIVE" }];

    const updatedList = [...approvedTarifas];
    if (approvedTarifa.fechaEfectiva >= activeTarifa.fechaEfectiva) {
      updatedList[activeIndex] = { ...activeTarifa, estado: "EXPIRED" };
      approvedTarifa = { ...approvedTarifa, estado: "ACTIVE" };
    } else {
      approvedTarifa = { ...approvedTarifa, estado: "EXPIRED" };
    }

    return [...updatedList, approvedTarifa];
  };

  const deleteRecord = (index) => {
    const updatedTarifas = [...approvedTarifas];
    updatedTarifas.splice(index, 1);
    setApprovedTarifas(updatedTarifas);
  };

  return (
    <Container maxWidth="md" style={{ marginTop: '20px' }}>
      <Typography variant="h4" align="center" gutterBottom>
        Administrador de Tarifas
      </Typography>
      {/* Formulario para agregar una nueva tarifa */}
      <form onSubmit={handleSubmit}>
        <TextField
          label="Nombre de Tarifa"
          value={nombre}
          onChange={(e) => setNombre(e.target.value)}
          fullWidth
          margin="normal"
        />
        <TextField
          label="Fecha Efectiva"
          type="date"
          value={fechaEfectiva}
          onChange={(e) => setFechaEfectiva(e.target.value)}
          fullWidth
          margin="normal"
          InputLabelProps={{
            shrink: true,
          }}
        />
        <TextField
          label="Costo Unitario"
          type="number"
          value={costoUnitario}
          onChange={(e) => setCostoUnitario(e.target.value)}
          fullWidth
          margin="normal"
        />
        <Button variant="contained" type="submit" color="primary">
          Agregar Tarifa
        </Button>
      </form>

      {/* Formulario para agregar una nueva tarifa */}
      <form onSubmit={handleSubmitSchedule}>
        <TextField
          label="Fecha Actual"
          type="date"
          value={fechaActual}
          onChange={(e) => setFechaActual(e.target.value)}
          fullWidth
          margin="normal"
          InputLabelProps={{
            shrink: true,
          }}
        />
        <Button variant="contained" type="submit" color="primary">
          Correr Schedule
        </Button>
      </form>

      {/* Tabla de tarifas pendientes de aprobación */}
      <Typography variant="h5" style={{ marginTop: '20px' }}>
        Tarifas Pendientes de Aprobación
      </Typography>
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Nombre de Tarifa</TableCell>
              <TableCell>Fecha Efectiva</TableCell>
              <TableCell>Costo Unitario</TableCell>
              <TableCell>Acción</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {pendingTarifas.map((tarifa, index) => (
              <TableRow key={index}>
                <TableCell>{tarifa.nombre}</TableCell>
                <TableCell>{tarifa.fechaEfectiva}</TableCell>
                <TableCell>{tarifa.costoUnitario}</TableCell>
                <TableCell>
                  <Button variant="contained" color="primary" onClick={() => handleApprove(index)}>
                    Aprobar
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Tabla de tarifas aprobadas */}
      <Typography variant="h5" style={{ marginTop: '20px' }}>
        Tarifas Aprobadas
      </Typography>
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Nombre de Tarifa</TableCell>
              <TableCell>Fecha Efectiva</TableCell>
              <TableCell>Costo Unitario</TableCell>
              <TableCell>Estado</TableCell>
              <TableCell>Eliminar</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {approvedTarifas.map((tarifa, index) => (
              <TableRow key={index}>
                <TableCell>{tarifa.nombre}</TableCell>
                <TableCell>{tarifa.fechaEfectiva}</TableCell>
                <TableCell>{tarifa.costoUnitario}</TableCell>
                <TableCell>{tarifa.estado}</TableCell>
                <TableCell>
                  <Button variant="contained" color="secondary" onClick={() => deleteRecord(index)}>
                    X
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Container>
  );
}

export default App;
