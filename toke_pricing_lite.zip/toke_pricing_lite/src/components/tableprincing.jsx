// src/Tabla.js
import React from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from '@mui/material';

function Tabla({ tarifas }) {
  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Nombre de Tarifa</TableCell>
            <TableCell>Fecha Efectiva</TableCell>
            <TableCell>Costo Unitario</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {tarifas.map((tarifa, index) => (
            <TableRow key={index}>
              <TableCell>{tarifa.nombre}</TableCell>
              <TableCell>{tarifa.fecha}</TableCell>
              <TableCell>{tarifa.costo}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}

export default Tabla;
