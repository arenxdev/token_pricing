// src/Formulario.js
import React, { useState } from 'react';
import { TextField, Button } from '@mui/material';

function Formulario({ onAgregar }) {
  const [nombre, setNombre] = useState('');
  const [fecha, setFecha] = useState('');
  const [costo, setCosto] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onAgregar({ nombre, fecha, costo });
    setNombre('');
    setFecha('');
    setCosto('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <TextField
        label="Nombre de Tarifa"
        value={nombre}
        onChange={(e) => setNombre(e.target.value)}
        fullWidth
        margin="normal"
      />
      <TextField
        label="Fecha Efectiva"
        value={fecha}
        onChange={(e) => setFecha(e.target.value)}
        fullWidth
        margin="normal"
      />
      <TextField
        label="Costo Unitario"
        value={costo}
        onChange={(e) => setCosto(e.target.value)}
        fullWidth
        margin="normal"
      />
      <Button variant="contained" type="submit" color="primary">
        Agregar Tarifa
      </Button>
    </form>
  );
}

export default Formulario;
